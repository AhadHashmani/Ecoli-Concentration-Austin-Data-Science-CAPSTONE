# How to Upload to GitHub in 3 Steps

## Step 1: Create Empty Repository on GitHub.com
1. Go to https://github.com/new
2. Repository name: `ecoli-austin-capstone`
3. Description: "Geographical and temporal analysis of E. coli concentrations in Austin"
4. Make it **Public**
5. **DO NOT** initialize with README, .gitignore, or license (we have them)
6. Click **Create repository**

You'll see a page with commands. You need the URL which will look like:
`https://github.com/YOUR_USERNAME/ecoli-austin-capstone.git`

## Step 2: Upload via GitHub Web Interface
**Easiest method - no terminal needed!**

1. Go to your new repository URL
2. Click **"uploading an existing file"** link (near top)
3. Or click **Add file** → **Upload files**
4. Drag and drop this entire folder's contents OR select files
5. Click **Commit changes**

**Note:** GitHub web UI is easiest for initial upload. If you want to upload many files:
- Drag the entire folder into the upload box
- GitHub will preserve the folder structure automatically

## Step 3 (Alternative): Upload via Command Line
If you prefer terminal:

```bash
cd path/to/ecoli-austin-capstone

git init
git add .
git commit -m "Initial commit: E. coli capstone project

- Add exploratory data analysis (R scripts)
- Add predictive modeling (Python notebooks)
- Include research paper and presentations
- Add comprehensive README and documentation"

git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ecoli-austin-capstone.git
git push -u origin main
```

## After Upload

### Add GitHub Topics (for discoverability)
1. Go to your repo
2. Click Settings → About
3. Add topics: `data-science`, `machine-learning`, `environmental-analysis`, `austin`, `python`, `r`

### Share on LinkedIn
Use the GitHub repo link in your LinkedIn post!

---

## Troubleshooting

**"Repository already exists"**
- You created a repo with README/gitignore. Delete it and start fresh.

**Large file warnings**
- The CSV file is ~1.1MB (acceptable)
- If it exceeds 100MB, use Git LFS (instructions below)

**File not showing**
- GitHub sometimes takes 30 seconds to display
- Refresh the page

---

## File Upload Size Limits
- Single file limit: 25 MB
- Repository limit: No strict limit, but best practice is <1 GB
- Your project: ~100 MB (well within limits)

Good luck! 🚀
