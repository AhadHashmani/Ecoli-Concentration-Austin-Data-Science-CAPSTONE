# Limitations & Future Work

## Limitations

1. **Geographic Bias:** Certain watersheds sampled more frequently; rural areas underrepresented
2. **Temporal Bias:** Samples concentrated during certain seasons may create misleading patterns
3. **Unexplained Variance:** R² = 0.68 leaves 32% unaccounted for
4. **Missing Variables:** Land use, pollution sources, water flow not included
5. **API Failures:** 5 of 3,832 weather requests failed

## Future Work

- Incorporate land-use and zoning data
- Map upstream pollution sources
- Develop real-time prediction system
- Time-series models (ARIMA, Prophet)
- Ensemble methods with hydrological variables
