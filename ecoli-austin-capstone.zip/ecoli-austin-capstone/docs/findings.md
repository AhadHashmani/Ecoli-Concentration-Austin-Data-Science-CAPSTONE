# Key Findings

## 1. Seasonal Patterns

**Finding:** E. coli concentrations exhibit robust seasonal cycling with peaks in late spring/early summer.

- **Peak Months:** May–June (median ≈ 110 MPN/100 mL)
- **Trough Months:** February, August (median ≈ 55 MPN/100 mL)
- **Pattern:** Consistent across all 12 years

**Implications:** Predictable seasonal risk allows for targeted monitoring.

## 2. Temperature as Critical Predictor

**Finding:** Most extreme contamination events cluster in the 70–90°F temperature range.

- **Data:** High-frequency spikes (20,000–75,000 MPN/100 mL) concentrated at 70–90°F
- **Mechanism:** Aligns with optimal growth temperature for E. coli
- **Site Variation:** Urban runoff sites show dramatic peaks; lakes show attenuated responses

## 3. Urban vs. Rural Contamination Patterns

**Finding:** Urban and rural watersheds show fundamentally different contamination dynamics.

- **Urban:** Frequent spikes 40,000–200,000 MPN/100 mL
- **Rural:** Typically <10,000 MPN/100 mL
- **Driver:** Stormwater runoff from impervious surfaces

## 4. Model Performance

**Finding:** Random forest model (R² = 0.68) outperforms linear approaches.

- **Top Predictors:** Temperature (0.28) > Site Type (0.22) > Precipitation (0.18)
- **Classification:** F1 = 0.72 for high-contamination events (>3000 MPN/100 mL)
