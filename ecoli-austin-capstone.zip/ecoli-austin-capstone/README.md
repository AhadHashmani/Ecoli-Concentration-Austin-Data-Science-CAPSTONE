# E. coli Concentration Analysis in Austin Watersheds

A comprehensive computational analysis of weather-driven *Escherichia coli* (E. coli) contamination patterns across Austin, Texas watersheds using R, Python, and machine learning.

![Status](https://img.shields.io/badge/Status-Completed-brightgreen)
![License](https://img.shields.io/badge/License-MIT-blue)
![Python](https://img.shields.io/badge/Python-3.9+-blue)
![R](https://img.shields.io/badge/R-4.0+-276DC3)

## 📋 Overview

This capstone project integrates **3,832 water quality observations** from the City of Austin (2013–2025) with real-time weather data from the Visual Crossing API to identify and model the key drivers of bacterial contamination in Austin's watersheds.

## 🔬 Key Findings

### 1. Temperature is a Critical Predictor
- Most extreme contamination events (20,000–75,000 MPN/100 mL) cluster in the **70–90°F range**
- Aligns with optimal growth temperature for E. coli strains (70–98°F)

### 2. Strong Seasonal Patterns
- **Peak months:** May–June (median ≈ 110 MPN/100 mL)
- **Trough months:** February, August (median ≈ 55 MPN/100 mL)

### 3. Urbanization Amplifies Contamination Spikes
- **Urban watersheds** (Shoal Creek, Waller Creek): 40,000–200,000 MPN/100 mL
- **Rural watersheds** (Walter E. Long Lake): typically <10,000 MPN/100 mL

### 4. Predictive Modeling Achieves 68% Variance Explained
- **Best Model:** Random Forest Regression (R² = 0.68)
- **Feature Importance:** Temperature (28%) > Site Type (22%) > Precipitation (18%)

## 📊 Project Structure

```
src/
├── data_preprocessing/      # ETL pipeline
├── exploratory_analysis/    # EDA & visualization
└── modeling/               # ML models
```

## 🚀 Quick Start

```bash
# Install Python dependencies
pip install -r requirements.txt

# Run exploratory analysis
Rscript src/exploratory_analysis/Time_Series_Analysis.R

# Run predictive modeling
jupyter notebook src/modeling/Modeling_Final_With_Validation.ipynb
```

## 🎓 Author

**Ahad Hashmani** | UT Austin | Scientific Computation & Data Sciences Certificate

## 📖 Citation

```bibtex
@thesis{hashmani2026ecoli,
  author = {Hashmani, Ahad},
  title = {Weather Conditions and Escherichia coli Concentration: 
           A Geographical Analysis in the Austin Area},
  school = {University of Texas at Austin},
  year = {2026}
}
```

## 📜 License

MIT License — See LICENSE file for details
